# Consumer Goods Anallysis Using SQL

