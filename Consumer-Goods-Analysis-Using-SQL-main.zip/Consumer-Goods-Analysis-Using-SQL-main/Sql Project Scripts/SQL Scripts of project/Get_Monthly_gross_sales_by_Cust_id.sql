call gdb0041.get_monthly_gross_sales_for_customer('70004070');
